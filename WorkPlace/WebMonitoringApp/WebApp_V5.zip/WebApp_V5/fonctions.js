<!--- Functions of Home menu --->
var navLinks = document.getElementById("navLinks");
var times = document.getElementById("times");
var bars = document.getElementById("bars");

function showMenu(){
	navLinks.style.right = "0";
	bars.style.visibility = "hidden";
}

function hideMenu(){
	navLinks.style.right = "-200px";
	bars.style.visibility = "visible";
}	

<!--- Functions of Map menu --->
var canvas=document.getElementById('myCanvas');
var width = canvas.width = 700;
var height = canvas.height = 700;
var ctx=canvas.getContext('2d');
var rayon = 0;
var interval;
var count = 0;

function degToRad(degrees) {
	return degrees * Math.PI / 180;
}


function draw_radar_background(){
	<!-- Circle background -->
	var grd = ctx.createRadialGradient(width*.5, height*.5, 0, width*.5, height*.5, 360);
	grd.addColorStop(0.07, "rgba(38,164,5,1)");
	grd.addColorStop(0.82, "rgba(2,79,20,1)");
	grd.addColorStop(1, "rgba(0,0,0,0.8)");
	
	ctx.fillStyle = grd;
	ctx.beginPath();
	ctx.arc(width*.5, height*.5, 350, degToRad(0), degToRad(360), false);
	ctx.fill();
	
	<!-- Middle cross line -->
	ctx.beginPath();
	ctx.strokeStyle = 'rgba(60,200,5,0.4)';
	ctx.lineWidth=2.5; 
	ctx.moveTo(width*.5, 0);
	ctx.lineTo(width*.5, height);
	ctx.moveTo(0, height*.5);
	ctx.lineTo(width, height*.5);
	ctx.stroke();
	
	<!-- grid/cadrillage -->
	ctx.beginPath(); 
	for (var x=50; x<width ; x+=50) {
		ctx.moveTo(x, 0);
		ctx.lineTo(x, height);
	}
	
	for (var y=50; y<height ; y+=50) {
		ctx.moveTo(0, y);
		ctx.lineTo(width, y);
	}
	ctx.strokeStyle = 'rgba(60,200,5,0.4)';
	ctx.lineWidth=2;
	ctx.stroke();
	
	<!-- Cercle pour supprimer la grid qui depassa de la zone de recherche -->
	var grd = ctx.createRadialGradient(width*.5, height*.5, 0, width*.5, height*.5, 360);
	grd.addColorStop(0.07, "rgba(255,255,255,0)");
	grd.addColorStop(0.94, "rgba(255,255,255,0)");
	grd.addColorStop(0.95, "rgba(255,255,255,1)");
	ctx.fillStyle = grd;
	ctx.beginPath();
	ctx.arc(width*.5, height*.5, 600, degToRad(0), degToRad(360), false);
	ctx.fill();
	
	<!-- Triangle position cible -->
	ctx.fillStyle = 'rgb(255, 0, 0)';
	ctx.beginPath();
	ctx.moveTo(width*.5, height*.5 - 25);
	ctx.lineTo(width*.5 + 15,  height*.5 + 15);
	ctx.lineTo(width*.5 - 15, height*.5 + 15);
	ctx.fill();
}

function draw_Beacons(){
	<!-- Position des balises -->
	ctx.fillStyle = 'rgb(255, 220, 0)';
	ctx.beginPath();
	ctx.arc(150, 150, 14, degToRad(0), degToRad(360), false);
	ctx.fill();
	ctx.beginPath();
	ctx.arc(150, 550, 14, degToRad(0), degToRad(360), false);
	ctx.fill();
	ctx.beginPath();
	ctx.arc(550, 550, 14, degToRad(0), degToRad(360), false);
	ctx.fill();
}

function draw_WavesForUser(){
	rayon = rayon + 30;
	var grd = ctx.createRadialGradient(width*.5, height*.5, 0, width*.5, height*.5, 360);
	grd.addColorStop(0.1, "rgba(255,0,0,0.7)");
	grd.addColorStop(0.6, "rgba(255,0,0,0.3)");
	grd.addColorStop(0.9, "rgba(0,0,0,0.1)");

	ctx.strokeStyle = grd;
	
	if (rayon<=350){
		ctx.beginPath();
		ctx.lineWidth="5";
		ctx.arc(width*.5, height*.5, rayon, degToRad(0), degToRad(360), false);
		ctx.stroke();	
	}
	else{
		clear_waves();
	}
}

function draw_WavesForBeacons(id){
	rayon = rayon + 30;
	if (rayon<=700){
		if (id==0){
			var grd = ctx.createRadialGradient(150, 150, 0, 150, 150, 720);
			grd.addColorStop(0.1, "rgba(255,200,0,0.6)");
			grd.addColorStop(0.3, "rgba(255,200,0,0.3)");
			grd.addColorStop(0.8, "rgba(0,0,0,0.1)");
			ctx.strokeStyle = grd;
			ctx.beginPath();
			ctx.lineWidth="5";
			ctx.arc(150, 150, rayon, degToRad(0), degToRad(360), false);
			ctx.stroke();
		}
		else if (id==1){
			var grd = ctx.createRadialGradient(150, 550, 0, 150, 550, 720);
			grd.addColorStop(0.1, "rgba(255,200,0,0.6)");
			grd.addColorStop(0.3, "rgba(255,200,0,0.3)");
			grd.addColorStop(0.8, "rgba(0,0,0,0.1)");
			ctx.strokeStyle = grd;
			ctx.beginPath();
			ctx.lineWidth="5";
			ctx.arc(150, 550, rayon, degToRad(0), degToRad(360), false);
			ctx.stroke();
		}
		else{
			var grd = ctx.createRadialGradient(550, 550, 0, 550, 550, 720);
			grd.addColorStop(0.1, "rgba(255,200,0,0.6)");
			grd.addColorStop(0.3, "rgba(255,200,0,0.3)");
			grd.addColorStop(0.8, "rgba(0,0,0,0.1)");
			ctx.strokeStyle = grd;
			ctx.beginPath();
			ctx.lineWidth="5";
			ctx.arc(550, 550, rayon, degToRad(0), degToRad(360), false);
			ctx.stroke();
		}
		<!-- Cercle pour supprimer la grid qui depassa de la zone de recherche -->
		var grd = ctx.createRadialGradient(width*.5, height*.5, 0, width*.5, height*.5, 360);
		grd.addColorStop(0.07, "rgba(255,255,255,0)");
		grd.addColorStop(0.94, "rgba(255,255,255,0)");
		grd.addColorStop(0.95, "rgba(255,255,255,1)");
		ctx.fillStyle = grd;
		ctx.beginPath();
		ctx.arc(width*.5, height*.5, 600, degToRad(0), degToRad(360), false);
		ctx.fill();
	}
	else{
		clear_waves();
	}
}

function clear_waves(){
	ctx.clearRect(0, 0, canvas.width, canvas.height);
	draw_radar_background();
	draw_Beacons();
	rayon = 0;
	clearInterval(interval);
	if(count >= 3){
		count = 0;
		interval = setInterval(draw_WavesForUser, 100);
	}
	else{
		interval=setInterval(function(){draw_WavesForBeacons(count-1)}, 80);
		count += 1;
	}
}

<!-- Init -->
draw_radar_background();
draw_Beacons();
interval = setInterval(draw_WavesForUser, 100);

<!-- Requêtes API -->

var invocation = new XMLHttpRequest();
var urlFlag = 'http://127.0.0.1:3000/api/v3/beacons/0';
var urlBeacons = 'http://127.0.0.1:3000/api/v3/beacons';

var requestFlag;
var resp;
var beacon_1;
var beacon_2;
var beacon_3;

function getFlag() {
  console.log("get flag");
  if(invocation) {
	invocation.open('GET', urlFlag, true);
    invocation.onreadystatechange = function () {
		if(invocation.readyState === 4 && invocation.status === 200) {
			resp = JSON.parse(invocation.responseText);
			if (resp["flag"] === 1) {
				getBeacons();
				setFlag();
			}
		}
	};
	invocation.withCredentials = false;
    invocation.send();
  }
}

function getBeacons() {
	if(invocation) {
		invocation.open('GET', urlBeacons, true);
		invocation.onreadystatechange = function () {
			if(invocation.readyState === 4 && invocation.status === 200) {
				resp = JSON.parse(invocation.responseText);
				beacon_1 = resp[1];
				beacon_2 = resp[2];
				beacon_3 = resp[3];
				console.log(resp);
			}
		};
		invocation.withCredentials = false;
		invocation.send();
	  }
}

function setFlag() {
	fetch(urlFlag,{
		method: 'PUT',
		headers: {'Content-Type':'application/json'},
		body: JSON.stringify({"flag": 0})
	})
	console.log("Flag mis a zero")
  }

requestFlag = setInterval(getFlag,5000);