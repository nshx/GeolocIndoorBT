/*
API GeoLocBT
Felix GOUBIN
*/

// Local Database
const beacons = require('./db/beacons.json');
// Server settings
const port = 3000;
const hostname = '127.0.0.1'; // Use Raspi IP
// Back-End Web App Framework
const express = require('express'); 
const app = express();
const apiVersion = '/api/v3';

// Middlewares
// Allowing WebApp to use API
app.use(function (req, res, next) {
    // Website you wish to allow to connect
    res.setHeader('Access-Control-Allow-Origin', '*');
    // Request methods you wish to allow
    res.setHeader(
        'Access-Control-Allow-Methods',
        'GET, POST, OPTIONS, PUT, PATCH, DELETE'
    );
    // Request headers you wish to allow
    res.setHeader(
        'Access-Control-Allow-Headers',
        'X-Requested-With,content-type'
    );
    // Website includes cookies in the requests sent
    res.setHeader('Access-Control-Allow-Credentials', true);
    // Pass to next layer of middleware
    next();
});
app.use(express.json());


// Express Routes
// HTTP Requests Allowed
app.route(`${apiVersion}/beacons`)
    // List every beacon
    .get(function(req,res) {
        res.status(200).json(beacons)
    })
    // Add 1 beacon
    .post(function(req,res) {
        const data = req.body;
        beacons.push(data);
        res.status(200).json(beacons[beacons.length-1]);
    });

app.route(`${apiVersion}/beacons/:id`)
    // Select 1 beacon by id
    .get(function(req,res) {
        const id = parseInt(req.params.id);
        res.status(200).json(beacons[id] || null);
    })
    // Modify 1 beacon by id
    .put(function(req,res) {
        const id = parseInt(req.params.id);
        const data = req.body;
        // Use key of JSON file to modify value/add new {key:value} to database
        beacons[id] = Object.assign(beacons[id], data);
        res.status(200).json(beacons[id])
    })
    // Remove 1 beacon by id
    .delete(function(req,res) {
        const id = parseInt(req.params.id);
        beacons.splice(beacons.indexOf(beacons[id]), 1);
        res.status(200).send(`Beacon no.${id} has been deleted`);
    });
    

// Express route for any other unrecognised incoming requests
app.get('*', function(req, res) {
    res.status(404).json({error: 'Beacon not found'});
});

// Launching API
app.listen(port, () => {
    console.log(`Server Started: http://${hostname}:${port}/`)
});