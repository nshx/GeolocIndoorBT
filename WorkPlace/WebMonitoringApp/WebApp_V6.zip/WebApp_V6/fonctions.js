<!--- Functions of Home menu --->
var navLinks = document.getElementById("navLinks");
var times = document.getElementById("times");
var bars = document.getElementById("bars");

function showMenu(){
	navLinks.style.right = "0";
	bars.style.visibility = "hidden";
}

function hideMenu(){
	navLinks.style.right = "-200px";
	bars.style.visibility = "visible";
}	

<!--- Functions of Map menu --->
var canvas=document.getElementById('myCanvas');
var width = canvas.width = 700;
var height = canvas.height = 700;
var ctx=canvas.getContext('2d');
var rayon = 0;
var interval;
var count = 0;
var scale_factor = 1; 
var scale = 12.5; // 12.5px = 1m
var pos_B = {"x1": 0, "y1": 0, "x2": 0, "y2": 0, "x3": 0, "y3": 0};
var pos_U = {"x": 350 - 0 * (scale * scale_factor), "y": 350 - 0 * (scale * scale_factor)};
var rssi = {"B1": -120, "B2": -120, "B3": -120}
var pos_inter = {"x12": 0, "y12": 0, "x13": 0, "y13": 0,
				 "x21": 0, "y21": 0, "x23": 0, "y23": 0,
				 "x31": 0, "y31": 0, "x32": 0, "y32": 0};
var d = {"d1":0, "d2":0, "d3":0};
var detection = 0 // Nb of beacons that detect us
var closest_beacon = "B";

function degToRad(degrees) {
	return degrees * Math.PI / 180;
}

function draw_radar_background(){
	<!-- Circle background -->
	var grd = ctx.createRadialGradient(width*.5, height*.5, 0, width*.5, height*.5, 360);
	grd.addColorStop(0.07, "rgba(38,164,5,1)");
	grd.addColorStop(0.82, "rgba(2,79,20,1)");
	grd.addColorStop(1, "rgba(0,0,0,0.8)");
	
	ctx.fillStyle = grd;
	ctx.beginPath();
	ctx.arc(width*.5, height*.5, 350, degToRad(0), degToRad(360), false);
	ctx.fill();
	
	<!-- Middle cross line -->
	ctx.beginPath();
	ctx.strokeStyle = 'rgba(60,200,5,0.4)';
	ctx.lineWidth=2.5; 
	ctx.moveTo(width*.5, 0);
	ctx.lineTo(width*.5, height);
	ctx.moveTo(0, height*.5);
	ctx.lineTo(width, height*.5);
	ctx.stroke();
	
	<!-- grid/cadrillage -->
	ctx.beginPath(); 
	for (var x=scale*scale_factor; x<width ; x+=scale*scale_factor) {
		ctx.moveTo(x, 0);
		ctx.lineTo(x, height);
	}
	
	for (var y=scale*scale_factor; y<height ; y+=scale*scale_factor) {
		ctx.moveTo(0, y);
		ctx.lineTo(width, y);
	}
	ctx.strokeStyle = 'rgba(60,200,5,0.4)';
	ctx.lineWidth=2;
	ctx.stroke();
	
	<!-- Cercle pour supprimer la grid qui depassa de la zone de recherche -->
	var grd = ctx.createRadialGradient(width*.5, height*.5, 0, width*.5, height*.5, 360);
	grd.addColorStop(0.07, "rgba(255,255,255,0)");
	grd.addColorStop(0.94, "rgba(255,255,255,0)");
	grd.addColorStop(0.95, "rgba(255,255,255,1)");
	ctx.fillStyle = grd;
	ctx.beginPath();
	ctx.arc(width*.5, height*.5, 600, degToRad(0), degToRad(360), false);
	ctx.fill();
}

function update_legend(symbole){
	if ((symbole === "-") && (scale_factor > 0.5)){
		scale_factor = scale_factor * 0.5;
	}
	else if ((symbole === "+") && (scale_factor < 2)){
		scale_factor = scale_factor * 2;
	}
	else{
		scale_factor = 1;
	}
	
	document.getElementById('title_canvas_legend').innerHTML = "Scale: 1m/carreau";
	document.getElementById('value_canvas_scale').innerHTML = "x" + scale_factor;
	
	draw_system();
	draw_distance_Beacon2User();
}

function draw_User(){
	<!-- Triangle position user -->
	ctx.fillStyle = 'rgb(255, 0, 0)';
	ctx.beginPath();
	ctx.moveTo(pos_U["x"], pos_U["y"] - 25);
	ctx.lineTo(pos_U["x"] + 15,  pos_U["y"] + 15);
	ctx.lineTo(pos_U["x"] - 15, pos_U["y"] + 15);
	ctx.fill();
}

function draw_Beacons(){
	<!-- Position des balises -->
	ctx.fillStyle = 'rgb(255, 220, 0)';
	ctx.beginPath();
	pos_B["x1"] = 350 - 0 * (scale * scale_factor); 
	pos_B["y1"] = 350 - 5 * (scale * scale_factor);
	ctx.arc(pos_B["x1"], pos_B["y1"], 14, degToRad(0), degToRad(360), false);
	ctx.fill();
	ctx.beginPath();
	pos_B["x2"] = 350 - 5 * (scale * scale_factor);
	pos_B["y2"] = 350 - 0 * (scale * scale_factor);
	ctx.arc(pos_B["x2"], pos_B["y2"], 14, degToRad(0), degToRad(360), false);
	ctx.fill();
	ctx.beginPath();
	pos_B["x3"] = 350 + 5 * (scale * scale_factor);
	pos_B["y3"] = 350 - 0 * (scale * scale_factor);
	ctx.arc(pos_B["x3"], pos_B["y3"], 14, degToRad(0), degToRad(360), false);
	ctx.fill();
}

function draw_WavesForUser(){
	rayon = rayon + 30;
	var grd = ctx.createRadialGradient(pos_U["x"], pos_U["y"], 0, pos_U["x"], pos_U["y"], 360);
	grd.addColorStop(0.1, "rgba(255,0,0,0.7)");
	grd.addColorStop(0.6, "rgba(255,0,0,0.3)");
	grd.addColorStop(0.9, "rgba(0,0,0,0.1)");

	ctx.strokeStyle = grd;
	
	if (rayon<=350){
		ctx.beginPath();
		ctx.lineWidth="5";
		ctx.arc(pos_U["x"], pos_U["y"], rayon, degToRad(0), degToRad(360), false);
		ctx.stroke();	
	}
	else{
		clear_waves();
	}
}

function draw_WavesForBeacons(id){
	rayon = rayon + 30;
	if (rayon<=700){
		var grd = ctx.createRadialGradient(pos_B["x1"], pos_B["y1"], 0, pos_B["x1"], pos_B["y1"], 720);
		grd.addColorStop(0.1, "rgba(255,200,0,0.6)");
		grd.addColorStop(0.3, "rgba(255,200,0,0.3)");
		grd.addColorStop(0.8, "rgba(0,0,0,0.1)");
		ctx.strokeStyle = grd;
		ctx.beginPath();
		ctx.lineWidth="5";
		ctx.arc(pos_B["x1"], pos_B["y1"], rayon, degToRad(0), degToRad(360), false);
		ctx.stroke();
		var grd = ctx.createRadialGradient(pos_B["x2"], pos_B["y2"], 0, pos_B["x2"], pos_B["y2"], 720);
		grd.addColorStop(0.1, "rgba(255,200,0,0.6)");
		grd.addColorStop(0.3, "rgba(255,200,0,0.3)");
		grd.addColorStop(0.8, "rgba(0,0,0,0.1)");
		ctx.strokeStyle = grd;
		ctx.beginPath();
		ctx.lineWidth="5";
		ctx.arc(pos_B["x2"], pos_B["y2"], rayon, degToRad(0), degToRad(360), false);
		ctx.stroke();
		var grd = ctx.createRadialGradient(pos_B["x3"], pos_B["y3"], 0, pos_B["x3"], pos_B["y3"], 720);
		grd.addColorStop(0.1, "rgba(255,200,0,0.6)");
		grd.addColorStop(0.3, "rgba(255,200,0,0.3)");
		grd.addColorStop(0.8, "rgba(0,0,0,0.1)");
		ctx.strokeStyle = grd;
		ctx.beginPath();
		ctx.lineWidth="5";
		ctx.arc(pos_B["x3"], pos_B["y3"], rayon, degToRad(0), degToRad(360), false);
		ctx.stroke();
		
		<!-- Cercle pour supprimer la grid qui depassa de la zone de recherche -->
		var grd = ctx.createRadialGradient(width*.5, height*.5, 0, width*.5, height*.5, 360);
		grd.addColorStop(0.07, "rgba(255,255,255,0)");
		grd.addColorStop(0.94, "rgba(255,255,255,0)");
		grd.addColorStop(0.95, "rgba(255,255,255,1)");
		ctx.fillStyle = grd;
		ctx.beginPath();
		ctx.arc(width*.5, height*.5, 600, degToRad(0), degToRad(360), false);
		ctx.fill();
	}
	else{
		clear_waves();
	}
}

function draw_distance_Beacon2User(calcul){
	var x = 0;
	var y = 0;
	for(i=0; i < 3; i++){
		console.log("Draw dist " + d["d"+ (i + 1)]);
		ctx.strokeStyle = "rgba(0,255,0,1)";
		ctx.beginPath();
		ctx.lineWidth="5";
		ctx.arc(pos_B["x"+(i+1)], pos_B["y"+(i+1)], (d["d"+ (i + 1)]*scale*scale_factor), degToRad(0), degToRad(360), false);
		ctx.stroke();
	}
	<!-- Cercle pour supprimer la grid qui depassa de la zone de recherche -->
	var grd = ctx.createRadialGradient(width*.5, height*.5, 0, width*.5, height*.5, 360);
	grd.addColorStop(0.07, "rgba(255,255,255,0)");
	grd.addColorStop(0.94, "rgba(255,255,255,0)");
	grd.addColorStop(0.95, "rgba(255,255,255,1)");
	ctx.fillStyle = grd;
	ctx.beginPath();
	ctx.arc(width*.5, height*.5, 600, degToRad(0), degToRad(360), false);
	ctx.fill();
	
	if(calcul==true){
		find_intersection_ofCircle();
	}
}

function find_intersection_ofCircle(){
	/* Position y de l'intersection des 3 cercles */
	console.log(pos_inter);
	switch (detection){
		case 0:
			console.log("We found no Beacon.");
			break;
		case 1:
			console.log("We found one Beacon.");
			pos_U["x"] = pos_B["x"+closest_beacon];
			pos_U["y"] = pos_B["y"+closest_beacon];;
			break;
		case 2:
			console.log("We found two Beacon.");
			var a, dx, dy, d_c, h, rx, ry;
			var x2, y2;
			var count = 0;
			var count1 = 0;

			if(d["d1"] == 0){
				count1 = 2;
				count = 3;		
			}
			else if(d["d2"] == 0){
				count1 = 1;
				count = 3;
			}
			else{
				count1 = 1;
				count = 2;
			}
					
			x0 = pos_B["x"+count1]
			x1 = pos_B["x"+count]
			y0 = pos_B["y"+count1]
			y1 = pos_B["y"+count]
			r0 = d["d"+count1] * scale * scale_factor;
			r1 = d["d"+count] * scale * scale_factor;
			
			dx = x1 - x0;
			dy = y1 - y0;
			
			console.log("dx: " + dx);
			console.log("dy: " + dy);

			/* Determine the straight-line distance between the centers. */
			d_c = Math.sqrt((dy*dy) + (dx*dx));
			console.log("d_c: " + d_c);
			
			/* Check for solvability. */
			if (d_c > (r0 + r1)) {
				/* no solution. circles do not intersect. */
				console.log("d_c > " + (r0 + r1));
			}
			if (d_c < Math.abs(r0 - r1)) {
				/* no solution. one circle is contained in the other */
				console.log("d_c < " + Math.abs(r0 - r1));
			}

			/* 'point 2' is the point where the line through the circle
			 * intersection points crosses the line between the circle
			 * centers.  
			 */

			/* Determine the distance from point 0 to point 2. */
			a = ((r0*r0) - (r1*r1) + (d_c*d_c)) / (2.0 * d_c) ;
			console.log("a:" + a);

			/* Determine the coordinates of point 2. */
			x2 = x0 + (dx * a/d_c);
			y2 = y0 + (dy * a/d_c);

			/* Determine the distance from point 2 to either of the
			 * intersection points.
			 */
			h = Math.sqrt((r0*r0) - (a*a));

			/* Now determine the offsets of the intersection points from
			 * point 2 */
			rx = -dy * (h/d_c);
			ry = dx * (h/d_c);

			/* Determine the absolute intersection points. */
			var xi = x2 + rx;
			var xi_prime = x2 - rx;
			var yi = y2 + ry;
			var yi_prime = y2 - ry;
			
			pos_inter["x"+count+count1] = xi;
			pos_inter["y"+count+count1] = yi;
			
			pos_inter["x"+count1+count] = xi_prime;
			pos_inter["y"+count1+count] = yi_prime;
			
			/* --- Gestion du centre des intersections pour affichage utilisateur avec approximation --- */
			var centerX = (pos_inter["x"+count+count1] + pos_inter["x"+count1+count]) / 2;
			var centerY = (pos_inter["y"+count+count1] + pos_inter["y"+count1+count]) / 2;
			
			/* --- Traitement du cas où il manque des intersections avec 3 cercles --- */
			if((isNaN(centerX)) || (isNaN(centerY))){
				pos_U["x"] = pos_B["x"+closest_beacon];
				pos_U["y"] = pos_B["y"+closest_beacon];;
			}
			else{
				pos_U["x"] = centerX;
				pos_U["y"] = centerY;
			}

			break;
		case 3:
			console.log("We found three Beacon.");
			var a, dx, dy, d_c, h, rx, ry;
			var x2, y2;
			var count = 2;
			var count1 = 1;

			for(i=0; i < 3; i++){
				if(i == 1){
					count = 3;
				}
				if(i == 2){
					count1 = 2;
				}
					
				x0 = pos_B["x"+count1]
				x1 = pos_B["x"+count]
				y0 = pos_B["y"+count1]
				y1 = pos_B["y"+count]
				r0 = d["d"+count1] * scale * scale_factor;
				r1 = d["d"+count] * scale * scale_factor;		

				dx = x1 - x0;
				dy = y1 - y0;
				
				console.log("dx: " + dx);
				console.log("dy: " + dy);

				/* Determine the straight-line distance between the centers. */
				d_c = Math.sqrt((dy*dy) + (dx*dx));
				console.log("d_c: " + d_c);
				
				/* Check for solvability. */
				if (d_c > (r0 + r1)) {
					/* no solution. circles do not intersect. */
					console.log("d_c > " + (r0 + r1));
				}
				if (d_c < Math.abs(r0 - r1)) {
					/* no solution. one circle is contained in the other */
					console.log("d_c < " + Math.abs(r0 - r1));
				}

				/* 'point 2' is the point where the line through the circle
				 * intersection points crosses the line between the circle
				 * centers.  
				 */

				/* Determine the distance from point 0 to point 2. */
				a = ((r0*r0) - (r1*r1) + (d_c*d_c)) / (2.0 * d_c) ;
				console.log("a:" + a);

				/* Determine the coordinates of point 2. */
				x2 = x0 + (dx * a/d_c);
				y2 = y0 + (dy * a/d_c);

				/* Determine the distance from point 2 to either of the
				 * intersection points.
				 */
				h = Math.sqrt((r0*r0) - (a*a));

				/* Now determine the offsets of the intersection points from
				 * point 2.
				 */
				rx = -dy * (h/d_c);
				ry = dx * (h/d_c);

				/* Determine the absolute intersection points. */
				var xi = x2 + rx;
				var xi_prime = x2 - rx;
				var yi = y2 + ry;
				var yi_prime = y2 - ry;
				
				console.log(xi_prime);
				
				if((count1==1) && (count == 3)){
					pos_inter["x"+(count1)+(count)] = xi;
					pos_inter["y"+(count1)+(count)] = yi;
				}
				else{
					pos_inter["x"+(count1)+(count)] = xi_prime;
					pos_inter["y"+(count1)+(count)] = yi_prime;
				}
		}
		/* --- Up to date the dico --- */
		pos_inter["x21"] = pos_inter["x12"];
		pos_inter["y21"] = pos_inter["y12"];
		pos_inter["x31"] = pos_inter["x13"];
		pos_inter["y31"] = pos_inter["y13"];
		pos_inter["x32"] = pos_inter["x23"];
		pos_inter["y32"] = pos_inter["y23"];
		
		/* --- Gestion du centre des intersections pour affichage utilisateur avec approximation --- */
		var centerX = (pos_inter["x21"] + pos_inter["x23"] + pos_inter["x31"]) / 3;
		var centerY = (pos_inter["y21"] + pos_inter["y23"] + pos_inter["y31"]) / 3;
		
		/* --- Traitement du cas où il manque des intersections avec 3 cercles --- */
		if((isNaN(centerX)) || (isNaN(centerY))){
			pos_U["x"] = pos_B["x"+closest_beacon];
			pos_U["y"] = pos_B["y"+closest_beacon];;
		}
		else{
			pos_U["x"] = centerX;
			pos_U["y"] = centerY;
		}
		console.log(pos_inter);
		console.log(pos_U);
		break;
	}
	
	/* --- Reaffichage du systeme avec les nouvelles positions de chaque entitée --- */
	draw_system();
	draw_distance_Beacon2User(false);
	count = 2;
	count1 = 1;
	
	/* --- Affichage des intersections (centrale) --- */
	for(i=0; i<3; i++){
		if(i == 1){
			count = 3;
		}
		if(i == 2){
			count1 = 2;
		}
		ctx.strokeStyle = "rgba(0,0,255,1)";
		ctx.beginPath();
		ctx.lineWidth="5";
		ctx.arc(pos_inter["x"+count1+count], pos_inter["y"+count1+count], 3, degToRad(0), degToRad(360), false);
		ctx.arc(pos_inter["x"+count+count1], pos_inter["y"+count+count1], 3, degToRad(0), degToRad(360), false);
		ctx.stroke();
	}
	
	/* --- Reset des variables pour nouvelle étude --- */
	pos_inter = {"x12": 0, "y12": 0, "x13": 0, "y13": 0,
				 "x21": 0, "y21": 0, "x23": 0, "y23": 0,
				 "x31": 0, "y31": 0, "x32": 0, "y32": 0};
	
	detection = 0;
}

function clear_waves(){
	ctx.clearRect(0, 0, canvas.width, canvas.height);
	draw_system();
	rayon = 0;
	clearInterval(interval);

	if(count == 0){
		interval = setInterval(draw_WavesForUser, 100);
		count += 1;
	}
	else if(count == 1){
		interval = setInterval(draw_WavesForBeacons, 80);
		count += 1;
	}
	else{
		Trilateration();
	}
}

function scan_area(){
	count = 0;
	rssi["B1"] = document.getElementById('inputB1').value;
	rssi["B2"] = document.getElementById('inputB2').value;
	rssi["B3"] = document.getElementById('inputB3').value;
	clear_waves();
}

<!-- Requêtes API -->

var invocation = new XMLHttpRequest();
var urlFlag = 'http://127.0.0.1:3000/api/v3/beacons/0';
var urlBeacons = 'http://127.0.0.1:3000/api/v3/beacons';

var requestFlag;
var resp;
var beacon_1;
var beacon_2;
var beacon_3;

function getFlag() {
  console.log("get flag");
  if(invocation) {
	invocation.open('GET', urlFlag, true);
    invocation.onreadystatechange = function () {
		if(invocation.readyState === 4 && invocation.status === 200) {
			resp = JSON.parse(invocation.responseText);
			if (resp["flag"] === 1) {
				getBeacons();
				setFlag();
			}
		}
	};
	invocation.withCredentials = false;
    invocation.send();
  }
}

function getBeacons() {
	if(invocation) {
		invocation.open('GET', urlBeacons, true);
		invocation.onreadystatechange = function () {
			if(invocation.readyState === 4 && invocation.status === 200) {
				resp = JSON.parse(invocation.responseText);
				beacon_1 = resp[1];
				beacon_2 = resp[2];
				beacon_3 = resp[3];
				rssi["B1"] = beacon_1.rssi;
				rssi["B2"] = beacon_2.rssi;
				rssi["B3"] = beacon_3.rssi;
				console.log(resp);
				d = Trilateration()
			}
		};
		invocation.withCredentials = false;
		invocation.send();
	  }
}

function setFlag() {
	fetch(urlFlag,{
		method: 'PUT',
		headers: {'Content-Type':'application/json'},
		body: JSON.stringify({"flag": 0})
	})
	console.log("Flag mis a zero")
  }
  
<!-- Triangulation -->
function Trilateration(){
	/* --- Valeur RSSI convertie en mW --- */
	/* --- -30dBm = 0m et -120dBm = 10m, d'après le protocole BT utilisé par les modules HC-05 "Bluetooth V2" --- */
					 
	var rssi_list = [rssi["B1"],
					 rssi["B2"],
					 rssi["B3"]];
	
	/* -- Etalonnage dico -> key = dBm : value = m -- */
	// Recupération des valeurs clés par tests réels
	var Etalonnage = {
						"-30": 1,
						"-40": 2,
						"-50": 3,
						"-60": 4,
						"-70": 5,
						"-80": 6,
						"-90": 7,
						"-100": 8,
						"-110": 9,
						"-120": 10
					}

	for(i=0; i <= (rssi_list.length - 1); i++){
		if((rssi_list[i] <= -30) && (rssi_list[i] >= -120)){
			if(Etalonnage[(rssi_list[i])] === undefined){
				var value_u = Etalonnage[(Math.floor(rssi_list[i]*0.1)*10)];
				var value_d = Etalonnage[((Math.floor(rssi_list[i]*0.1)*10)+10)];
				d["d"+(i+1)] = (value_u + value_d) * 0.5;  // Moyenne entre 2 distances
				detection = detection + 1;
			}
			else
				d["d"+(i+1)] = Etalonnage[rssi_list[i]]; // Valeur exact pour la distance
				detection = detection + 1;
		}
		else{
			d["d"+(i+1)] = 0;
			rssi_list[i] = -1000;
		}
	}
	console.log(d);
	
	highest_rssi = Math.max(...rssi_list);
	console.log(highest_rssi);
	closest_beacon = (rssi_list.indexOf(highest_rssi.toString()) + 1);
	console.log(closest_beacon);
	
	draw_distance_Beacon2User(true);
	
	return d;
}

function draw_system(){
	draw_radar_background();
	draw_Beacons();
	draw_User();
}

<!-- Init/Main -->
draw_system();
//requestFlag = setInterval(getFlag, 5000);

