/* API GeoLocBT
install nodeJS
install npm
npm i -s express
*/

// const http = require('http');
const express = require('express');
const beacons = require('./db/beacons.json');

const app = express();

const apiVersion = '/api/v3';
const port = 3000;
const hostname = '127.0.0.1';

// Middleware
app.use(function (req, res, next) {
    // Website you wish to allow to connect
    res.setHeader('Access-Control-Allow-Origin', '*');
    // Request methods you wish to allow
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');
    // Request headers you wish to allow
    res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type');
    // Set to true if you need the website to include cookies in the requests sent
    // to the API (e.g. in case you use sessions)
    res.setHeader('Access-Control-Allow-Credentials', true);
    // Pass to next layer of middleware
    next();
});
app.use(express.json());

// Homepage
app.route(`/`)
    .get(function(req, res) {
        res.sendFile('C:/Users/fgoub/Desktop/projects/api/v3/index.html');
    });

app.route(`${apiVersion}/beacons`)
    // List every beacon
    .get(function(req,res) {
        res.status(200).json(beacons)
    })
    // Add 1 beacon
    .post(function(req,res) {
        const data = req.body;
        beacons.push(data);
        res.status(200).json(beacons[beacons.length-1]);
    });

app.route(`${apiVersion}/beacons/:id`)
    // Select 1 beacon by id
    .get(function(req,res) {
        const id = parseInt(req.params.id);
        res.status(200).json(beacons[id] || null);
    })
    // Modify 1 beacon
    .put(function(req,res) {
        const id = parseInt(req.params.id);
        const data = req.body;
        beacons[id] = Object.assign(beacons[id], data);
        res.status(200).json(beacons[id])
    })
    // Remove 1 beacon by id
    .delete(function(req,res) {
        const id = parseInt(req.params.id);
        beacons.splice(beacons.indexOf(beacons[id]), 1);
        res.status(200).send(`Beacon no.${id} has been deleted`);
    });
    

// Express route for any other unrecognised incoming requests
app.get('*', function(req, res) {
    res.status(404).json({error: 'Beacon not found'});
});

// Launching API
app.listen(port, () => {
    console.log(`Server Started: http://${hostname}:${port}/`)
});