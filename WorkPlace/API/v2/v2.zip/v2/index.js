/* API GeoLocBT
install nodeJS
install npm
npm i -s express
*/

const http = require('http');
const express = require('express');
const beacons = require('./db/beacons.json');
const app = express();
const port = 3000;
const hostname = '127.0.0.1';

// Middleware
app.use(express.json())

// Homepage
app.route('/')
    .get(function(req, res) {
        res.sendFile('C:/Users/fgoub/Desktop/projects/api/v2/index.html');
    });

app.route('/beacons')
    // List every beacon
    .get(function(req,res) {
        res.status(200).json(beacons);
    // Add 1 beacon
    })
    .post(function(req,res) {
        beacons.push(req.body);
        res.status(200).json(beacons);
    })
    // Modify 1 beacon
    .put(function(req,res) {
        const id = parseInt(req.body.id);
        let beacon = beacons.find(beacon => beacon.id === id)
        if (beacon != null) {
            Object.keys(req.body).forEach(function(key) {
                beacon[key] = req.body[key];
            });
            res.status(200).json(beacon);
        }
        else res.status(404).send({error: 'Beacon not found'}); 
    });

app.route('/beacons/:id')
    // Select 1 beacon by id
    .get(function(req,res) {
        const id = parseInt(req.params.id);
        const beacon = beacons.find(beacon => beacon.id === id);
        if (beacon !== undefined) {
            res.status(200).json(beacon);
        }
        else {
            res.status(404).send({error: 'Beacon not found'});
            return;
        }
    })
    // Remove 1 beacon by id
    .delete(function(req,res) {
        const id = parseInt(req.params.id);
        let beacon = beacons.find(beacon => beacon.id === id);
        if (beacon != null) {
            beacons.splice(beacons.indexOf(beacon),1);
            res.status(200).send(`Beacon no.${id} has been deleted`);
        }
        else res.status(404).send({error: 'Delete: Beacon not found'});        
    });
    

// Express route for any other unrecognised incoming requests
app.get('*', function(req, res) {
    res.status(404).send({error: 'Beacon not found'});
});

// Launching API
app.listen(port, () => {
    console.log(`Server Started: http://${hostname}:${port}/`)
});